#ifndef UCA1_H_
#define UCA1_H_

#include "..\base.h"

EXTERN Void UCA1_init(Void);
EXTERN Void UCA1_emit (const UChar adr, const UChar val);

#endif /* UCA1_H_ */
