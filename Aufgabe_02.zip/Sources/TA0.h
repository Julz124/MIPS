#include "..\base.h"

#ifndef TA0_H_
#define TA0_H_

#define MUSTER1 0
#define MUSTER2 1
#define MUSTER3 2
#define MUSTER4 3
#define MUSTER5 4
#define MUSTER6 5

EXTERN Void TA0_init(Void);
EXTERN Void set_blink_muster(UInt);

#endif /* TA0_H_ */
