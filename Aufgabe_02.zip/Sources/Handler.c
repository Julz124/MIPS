#include <msp430.h>
#include "Handler.h"
#include "event.h"
#include "UCA1.h"

#define DIGISIZE 4
#define BASE     8 // Basis des Zahlensystems kann zwischen 2 und 16 gew�hlt werden

// ----------------------------------------------------------------------------

GLOBAL Void Button_Handler(Void) {

}

// ----------------------------------------------------------------------------


GLOBAL Void Number_Handler(Void) {

}

// ----------------------------------------------------------------------------



GLOBAL Void AS1108_Handler(Void) {

}

// ----------------------------------------------------------------------------

GLOBAL Void Handler_init(Void) {

}

