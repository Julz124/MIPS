#include "..\base.h"

#ifndef TA1_H_
#define TA1_H_

EXTERN Void TA1_init(Void);

#endif /* TA1_H_ */
